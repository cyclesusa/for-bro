import React from 'react';
import { Github, Linkedin, Mail, Database, Code, Brain, GraduationCap, Phone } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white animate-gradient">
      {/* Hero Section */}
      <header className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl mx-auto text-center animate-float">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">
              TEJA M
            </h1>
            <p className="text-2xl md:text-3xl text-gray-300 mb-8 transform transition-all duration-500 hover:scale-105">
              Data Scientist & Web Developer
            </p>
            <div className="flex justify-center gap-6 mb-12">
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Github className="w-8 h-8" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Linkedin className="w-8 h-8" />
              </a>
              <a href="mailto:your.email@example.com" className="text-gray-400 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Mail className="w-8 h-8" />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* About Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-16 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
            About Me
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="glass-effect rounded-2xl p-8 shadow-2xl transform transition-all duration-500 hover:scale-105">
              <div className="flex items-center mb-8">
                <GraduationCap className="w-8 h-8 mr-4 text-blue-400" />
                <div>
                  <h3 className="text-2xl font-semibold">Education</h3>
                  <p className="text-gray-300">SIMATS University</p>
                  <p className="text-gray-300">Artificial Intelligence and Data Science</p>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-12">
                <div className="space-y-6">
                  <div className="flex items-start group">
                    <Database className="w-8 h-8 mr-4 text-purple-400 group-hover:animate-bounce" />
                    <div>
                      <h4 className="text-xl font-semibold mb-2">Data Science</h4>
                      <p className="text-gray-300">Specialized in data analysis, machine learning, and statistical modeling</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="flex items-start group">
                    <Code className="w-8 h-8 mr-4 text-green-400 group-hover:animate-bounce" />
                    <div>
                      <h4 className="text-xl font-semibold mb-2">Web Development</h4>
                      <p className="text-gray-300">Full-stack development with modern technologies and frameworks</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-16 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
            Skills
          </h2>
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            <div className="glass-effect rounded-2xl p-8 transform transition-all duration-500 hover:scale-105">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <Database className="w-6 h-6 mr-3 text-purple-400" />
                Data Science
              </h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                  <span>Machine Learning</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                  <span>Statistical Analysis</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                  <span>Python & R</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                  <span>Data Visualization</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                  <span>Big Data Processing</span>
                </li>
              </ul>
            </div>
            <div className="glass-effect rounded-2xl p-8 transform transition-all duration-500 hover:scale-105">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <Code className="w-6 h-6 mr-3 text-green-400" />
                Web Development
              </h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>React & TypeScript</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>Node.js</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>HTML & CSS</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>Database Management</span>
                </li>
                <li className="flex items-center space-x-2 transition-all duration-300 hover:translate-x-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>RESTful APIs</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-16 text-center bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-blue-400">
            Contact Me
          </h2>
          <div className="max-w-2xl mx-auto glass-effect rounded-2xl p-8 transform transition-all duration-500 hover:scale-105">
            <div className="space-y-6">
              <div className="flex items-center space-x-4 group">
                <Phone className="w-6 h-6 text-blue-400 group-hover:animate-bounce" />
                <a href="tel:+919345280148" className="text-xl text-gray-300 hover:text-white transition-colors">
                  +91 93452 80148
                </a>
              </div>
              <div className="flex items-center space-x-4 group">
                <Mail className="w-6 h-6 text-purple-400 group-hover:animate-bounce" />
                <a href="mailto:your.email@example.com" className="text-xl text-gray-300 hover:text-white transition-colors">
                  your.email@example.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p className="transform transition-all duration-300 hover:scale-105">© 2024 TEJA M. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;